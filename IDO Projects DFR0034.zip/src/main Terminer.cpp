/*
  Titre      : DEMO DFR0034 - MKR 1000 - Thingsboard
  Auteur     : André Roussel (modifier par Demba)
  Date       : 02/12/2021
  Description: lecture du TMP36 et envoie de cette valeur a une fréquences spécifique sur la plateforme IDO Thingsbaord
  Droits     : Reproduction permise pour usage pédagogique
  Version    : 0.0.4
*/

#include <Arduino.h>
#include "WIFIConnector_MKR1000.h"
#include "MQTTConnector.h"


const int ANALOG_PIN  = A1;  // Utilisation de la broche A1 pour lecture analogue
int AnalogValue       = 0;    // Variable pour contenir la valeur lue de la broche analogue
 int val;

void setup() {
  
  Serial.begin(9600);             // Activation du port série pour affichage dans le moniteur série

  wifiConnect();                  //Branchement au réseau WIFI
  MQTTConnect();                  //Branchement au broker MQTT

  pinMode(ANALOG_PIN, INPUT);     // Pour une bonne lecture, la broche analogique doit être placé en mode entré explicitment
}


// Boucle infinie qui permet au uC de faire une ou plusieurs taches sans arrêt

void loop() {

 /*AnalogValue = analogRead(ANALOG_PIN)*/; 

  
      val=analogRead(A1);   //connect mic sensor to Analog 0
      Serial.println(val,DEC);//print the sound value to serial
      appendPayload("DFR0034", val);
      sendPayload();

      delay(500);

    
}

